package ru.gb.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorFrame extends JFrame {
    public CalculatorFrame() {
        setTitle("Calculator v1.0");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBounds(150, 50, 400, 500);
        setLayout(new BorderLayout());

        JTextField inputField = new JTextField();
        add(inputField, BorderLayout.NORTH);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(5, 3));
        add(bottomPanel, BorderLayout.CENTER);

        DigitButtonActionListener DigitButtonActionListener = new DigitButtonActionListener(inputField);
        for (int i = 0; i <= 9; i++) {
            JButton JButton = new JButton(String.valueOf(i));
            JButton.addActionListener(DigitButtonActionListener);
            bottomPanel.add(JButton);
        }


        JButton plus = new JButton("+");
        plus.addActionListener(DigitButtonActionListener);
        bottomPanel.add(plus);

        JButton minus = new JButton("-");
        minus.addActionListener(DigitButtonActionListener);
        bottomPanel.add(minus);

        JButton multiply = new JButton("*");
        multiply.addActionListener(DigitButtonActionListener);
        bottomPanel.add(multiply);

        JButton divide = new JButton("/");
        divide.addActionListener(DigitButtonActionListener);
        bottomPanel.add(divide);

        JButton calc = new JButton("=");
        calc.addActionListener(new CalcActionListener(inputField));
        bottomPanel.add(calc);

        JButton clear = new JButton("C");
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              inputField.setText("");
            }
        });
        bottomPanel.add(clear);

        setVisible(true);
    }
}
