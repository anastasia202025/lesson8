package ru.gb.gui;

public class Main {
    public static void main(String[] args) {
        new CalculatorFrame();

    }
}
